
export interface Lap {
  name: string;
  duration: number; // in seconds
}
